/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ass;

import java.util.Scanner;

/**
 *
 * @author ACER
 */
public class Ass {

    /**
     * @param args the command line arguments
     */
   static  void generateStd(int num){
         for(int i=0;i<num;i++)
         {
           colllege.student.add(new colllege());
             colllege.student.get(i).Stdid=i;
         }
         
         
     }
    static  void generateCO(int num){
         for(int i=0;i<num;i++)
         {
           colllege.course.add(new colllege());
             colllege.course.get(i).CoID=i;
         }
         
         
     }
    public static void main(String[] args) {
        Scanner sc =new Scanner (System.in);
       System.out.println("Enter no.of students");
        int a =sc.nextInt();
                System.out.println("Enter no.of courses");
        int b =sc.nextInt();
        char c='a';
        generateStd(a);
        generateCO(b);
        while(true)
        {
            System.out.println("enter student id");
        a =sc.nextInt();
        if(a==-1)
            break;
        b =sc.nextInt();
        c=sc.next().charAt(0);
        colllege.AddCourse(a, b, c);
        
        }
        int z =0;
        while(true)
        {
            System.out.println("1 to course 2 to student");
            z=sc.nextInt();
            if(z==1){
                System.out.println("choose course to print");
                            z=sc.nextInt();

            colllege.printCO(z);
            }
            else if(z==2){
                                System.out.println("choose studentto print");
                                            z=sc.nextInt();

            colllege.printStd(z);
            }
            else break;
        
        }
    }
    
}
