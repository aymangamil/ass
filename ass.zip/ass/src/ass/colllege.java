/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ass;

import java.util.ArrayList;

/**
 *
 * @author ACER
 */
public class colllege {
 static   ArrayList<colllege> student=new ArrayList();
 static   ArrayList<colllege> course=new ArrayList();
    node headStd,tailStd,headCo,tailCO;
    
    int Stdid,CoID;
    
    
   static void AddCourse(int s,int c ,char g)
    {   node n = new node(s,c,g);
        // check student phase 0 
        if(student.get(s).headCo==null)
        {
        student.get(s).headCo=student.get(s).tailCO=n;
        
        // check course 
        // (0,0)
        if(course.get(c).headStd==null)
            course.get(c).headStd=course.get(c).tailStd=n;
        //(0,1)
        else{
            course.get(c).tailStd.nextStd=n;
            course.get(c).tailStd=course.get(c).headStd.nextStd;
        }
        }
        // student  1
        // (1,0)
        else{
            student.get(s).tailCO.nextCo=n;
            student.get(s).tailCO=student.get(s).tailCO.nextCo;
                
            if(course.get(c).headStd==null)
            course.get(c).headStd=course.get(c).tailStd=n;
        //(1,1)
        else{
            course.get(c).tailStd.nextStd=n;
            course.get(c).tailStd=course.get(c).headStd.nextStd;
        }
        
        }
    }

        static void printCO(int c)
        {
        node current =course.get(c).headStd;
        while(current!=null){
                System.out.println("Student:    "+current.stdID+"   course :"+current.coID+"    grade:"+current.grade);
        current =current.nextStd;
        }
        
        }
         static void printStd(int c)
        {
        node current =student.get(c).headCo;
        while(current!=null){
                System.out.println("Student:    "+current.stdID+"   course :"+current.coID+"    grade:"+current.grade);
        current =current.nextCo;
        }
        
        }
}
