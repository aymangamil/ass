/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ass;

/**
 *
 * @author ACER
 */
public class node {
    int stdID,coID;
    char grade;
    node nextCo,nextStd;
    
    node(int stdID,int coID,char grade)
    {
    this.coID=coID;
    this.stdID=stdID;
    this.grade=grade;
    this.nextCo=null;
    this.nextStd=null;
    
    }        
    
}
